<?php
// Default PHP configuration
$db_host = "localhost";
$db_user = "root";
$db_password = "SuperSecretAdminPassword123!";
$db_name = "mydb";
?>
